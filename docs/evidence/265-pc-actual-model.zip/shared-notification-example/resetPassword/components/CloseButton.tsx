type Props = { onClose: () => void };

export function CloseButton({ onClose }: Props) {
  return <button data-node-id="closeButton" type="button" onClick={onClose} className="flex items-center justify-center w-auto h-[40px] flex-[0_0_40px] min-h-0 shrink-0 text-[#FFFFFF] [font-family:'Inter'] text-[14px] font-semibold leading-[21px] tracking-[0px] text-left bg-[#2563EB] rounded-[8px]">닫기</button>;
}
