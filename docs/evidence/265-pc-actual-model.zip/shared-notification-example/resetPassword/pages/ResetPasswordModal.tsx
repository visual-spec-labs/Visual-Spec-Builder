import { Title } from "../components/Title";
import { CloseButton } from "../components/CloseButton";

type Actions = {
  onNavigate: (target: string) => void;
  onOpenModal: (target: string) => void;
  onClose: () => void;
};

export default function ResetPasswordModal({ onClose }: Actions) {
  return (
    <div data-node-id="root" className="flex flex-col gap-[16px] pt-[24px] pr-[24px] pb-[24px] pl-[24px] justify-start items-stretch bg-[#FFFFFF] w-full flex-[1_0_auto]">
      <Title />
      <CloseButton onClose={onClose} />
    </div>
  );
}
