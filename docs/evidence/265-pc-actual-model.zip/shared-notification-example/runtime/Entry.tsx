import ProjectHost from "./Host";
export default function ProjectEntry() { return <ProjectHost />; }
