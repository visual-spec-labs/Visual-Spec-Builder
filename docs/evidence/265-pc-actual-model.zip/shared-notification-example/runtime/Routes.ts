import type { ComponentType } from "react";
import Screen0 from "../login/pages/LoginPage";
import Screen1 from "../dashboard/pages/DashboardPage";
import Screen2 from "../resetPassword/pages/ResetPasswordModal";
export interface ScreenActions { onNavigate: (target: string) => void; onOpenModal: (target: string) => void; onClose: () => void; }
export const entryPageId = "login";
export const pageScreens = new Map<string, ComponentType<ScreenActions>>([["login", Screen0],["dashboard", Screen1]]);
export const modalScreens = new Map<string, ComponentType<ScreenActions>>([["resetPassword", Screen2]]);
export const modalNames = new Map<string, string>([["resetPassword", "ResetPasswordModal"]]);
export const modalSizes = new Map<string, { width: number; height: number }>([["resetPassword", {"height":320,"width":480}]]);
