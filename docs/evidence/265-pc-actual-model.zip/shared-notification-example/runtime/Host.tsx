import { useCallback, useEffect, useRef, useState, type RefObject } from "react";
import { entryPageId, pageScreens, modalScreens, modalSizes, modalNames, type ScreenActions } from "./Routes";
function viewport() {
  const visual = window.visualViewport;
  return { width: visual?.width ?? window.innerWidth, height: visual?.height ?? window.innerHeight, left: visual?.offsetLeft ?? 0, top: visual?.offsetTop ?? 0 };
}
function ModalSurface({ id, actions, trigger, fallback }: { id: string; actions: ScreenActions; trigger: RefObject<HTMLElement | null>; fallback: RefObject<HTMLDivElement | null> }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const panel = useRef<HTMLDivElement>(null);
  const [view, setView] = useState(viewport);
  const Screen = modalScreens.get(id)!;
  const size = modalSizes.get(id)!;
  useEffect(() => {
    const element = dialog.current!;
    const locked = [document.documentElement, document.body, fallback.current].filter((node): node is HTMLElement => node !== null).map(node => ({ node, overflow: node.style.getPropertyValue("overflow"), priority: node.style.getPropertyPriority("overflow"), left: node.scrollLeft, top: node.scrollTop }));
    for (const item of locked) item.node.style.setProperty("overflow", "hidden");
    element.showModal();
    return () => {
      element.close();
      for (const item of locked) {
        if (item.overflow) item.node.style.setProperty("overflow", item.overflow, item.priority);
        else item.node.style.removeProperty("overflow");
        item.node.scrollTo(item.left, item.top);
      }
      (trigger.current?.isConnected ? trigger.current : fallback.current)?.focus({ preventScroll: true });
    };
  }, [trigger, fallback]);
  useEffect(() => {
    const update = () => setView(viewport());
    window.addEventListener("resize", update); window.visualViewport?.addEventListener("resize", update); window.visualViewport?.addEventListener("scroll", update);
    return () => { window.removeEventListener("resize", update); window.visualViewport?.removeEventListener("resize", update); window.visualViewport?.removeEventListener("scroll", update); };
  }, []);
  // Initial focus belongs to the panel so a distant first control cannot hide the introduction.
  useEffect(() => { panel.current?.focus({ preventScroll: true }); panel.current?.scrollTo(0, 0); }, [id]);
  const availableHeight = "max(0px, calc(" + view.height + "px - 32px - env(safe-area-inset-top) - env(safe-area-inset-bottom)))";
  const minimumHeight = "min(" + size.height + "px, " + availableHeight + ")";
  return <dialog ref={dialog} aria-label={modalNames.get(id) ?? id} className="vsb-project-dialog"
    onClick={event => event.stopPropagation()}
    onCancel={event => { event.preventDefault(); actions.onClose(); }}
    onKeyDown={event => {
      event.stopPropagation(); if (event.key !== "Tab") return;
      const items = [...event.currentTarget.querySelectorAll<HTMLElement>("button:not(:disabled),input:not(:disabled),a[href],select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex='-1'])")].filter(item => item.getClientRects().length > 0);
      if (!items.length) { event.preventDefault(); panel.current?.focus(); }
      else if (event.shiftKey && (document.activeElement === items[0] || !items.includes(document.activeElement as HTMLElement))) { event.preventDefault(); items.at(-1)?.focus(); }
      else if (!event.shiftKey && document.activeElement === items.at(-1)) { event.preventDefault(); items[0].focus(); }
    }}
    style={{ position:"fixed", left:view.left, top:view.top, width:view.width, height:view.height, margin:0, maxWidth:"none", maxHeight:"none", border:0, padding:0, background:"rgba(0,0,0,0.4)" }}>
    <style>{".vsb-project-dialog::backdrop{background:transparent}.vsb-project-modal-content > *{width:100%!important;height:auto!important;min-height:" + minimumHeight + "!important;flex:none!important;box-sizing:border-box!important}"}</style>
    <div style={{ display:"flex", width:"100%", height:"100%", alignItems:"center", justifyContent:"center", boxSizing:"border-box", padding:"calc(16px + env(safe-area-inset-top)) calc(16px + env(safe-area-inset-right)) calc(16px + env(safe-area-inset-bottom)) calc(16px + env(safe-area-inset-left))" }}>
      <div ref={panel} tabIndex={-1} className="vsb-project-modal-content" style={{ width:size.width, maxWidth:"100%", minHeight:minimumHeight, maxHeight:availableHeight, overflow:"auto", overscrollBehavior:"contain" }} onFocusCapture={event => event.target.scrollIntoView({ block:"nearest", inline:"nearest" })}>
        <Screen {...actions} />
      </div>
    </div>
  </dialog>;
}
export default function ProjectHost() {
  const [pageId, setPageId] = useState(entryPageId);
  const [modalId, setModalId] = useState<string | null>(null);
  const trigger = useRef<HTMLElement | null>(null);
  const fallback = useRef<HTMLDivElement>(null);
  const onClose = useCallback(() => setModalId(null), []);
  const onNavigate = useCallback((target: string) => { if (pageScreens.has(target)) { setPageId(target); setModalId(null); } }, []);
  const onOpenModal = useCallback((target: string) => {
    if (!modalScreens.has(target)) return;
    if (modalId === null) trigger.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    setModalId(target);
  }, [modalId]);
  const actions = { onNavigate, onOpenModal, onClose };
  const Page = pageScreens.get(pageId)!;
  return <div ref={fallback} tabIndex={-1} data-vsb-project-host="">
    <Page {...actions} />
    {modalId !== null && <ModalSurface id={modalId} actions={actions} trigger={trigger} fallback={fallback} />}
  </div>;
}
