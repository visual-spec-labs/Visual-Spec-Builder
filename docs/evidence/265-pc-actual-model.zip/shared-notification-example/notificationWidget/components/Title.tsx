type Props = { content?: string; color?: string };

export function Title({ content = "새 알림", color = "#0F172A" }: Props) {
  return <p data-node-id="title" className="self-stretch h-auto flex-[0_0_auto] min-h-0 m-0 whitespace-pre-wrap [font-family:'Inter'] text-[14px] font-normal leading-[21px] tracking-[0px] text-left" style={{ color }}>{content}</p>;
}
