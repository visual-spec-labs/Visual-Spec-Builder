import { Title } from "./Title";

type Props = {
  onNavigate: (target: string) => void;
  onOpenModal: (target: string) => void;
  onClose: () => void;
  titleContent?: string;
  titleColor?: string;
};

export function NotificationWidget({ titleContent, titleColor }: Props) {
  return (
    <div data-node-id="root" className="flex flex-col gap-[16px] pt-[16px] pr-[16px] pb-[16px] pl-[16px] justify-start items-stretch bg-[#FFFFFF] w-full h-auto">
      <Title content={titleContent} color={titleColor} />
    </div>
  );
}
