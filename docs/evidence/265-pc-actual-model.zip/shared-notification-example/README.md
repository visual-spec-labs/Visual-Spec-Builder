# Shared notification example

프로젝트 전체 화면과 모달, 참조된 공유 widget, GUI runtime, 검증한 이미지 bytes를 포함합니다.

진입점: runtime/Entry.tsx. React와 Tailwind 환경에 통합하고 package.json 의존성을 확인하세요.

파일/참조/입력 지문 검사는 실제 typecheck, production build, 브라우저 시각 검증을 대신하지 않습니다.
참조되지 않은 widget 0개는 생성 범위에서 제외했습니다.
