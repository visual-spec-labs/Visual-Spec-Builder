type Props = { onOpenModal: (target: string) => void };

export function ForgotButton({ onOpenModal }: Props) {
  return <button data-node-id="forgotButton" type="button" onClick={() => onOpenModal("resetPassword")} className="flex items-center justify-center w-auto h-[40px] flex-[0_0_40px] min-h-0 shrink-0 text-[#FFFFFF] [font-family:'Inter'] text-[14px] font-semibold leading-[21px] tracking-[0px] text-left bg-[#2563EB] rounded-[8px]">비밀번호 찾기</button>;
}
