import { NotificationWidget } from "../../notificationWidget/components/NotificationWidget";

type Props = {
  onNavigate: (target: string) => void;
  onOpenModal: (target: string) => void;
  onClose: () => void;
};

export function SharedNotification({ onNavigate, onOpenModal, onClose }: Props) {
  return (
    <div data-node-id="sharedNotification" className="w-[320px] h-[120px] shrink-0">
      <NotificationWidget onNavigate={onNavigate} onOpenModal={onOpenModal} onClose={onClose} />
    </div>
  );
}
