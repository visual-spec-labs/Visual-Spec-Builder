export function Title() {
  return <p data-node-id="title" className="self-stretch h-auto flex-[0_0_auto] min-h-0 m-0 whitespace-pre-wrap text-[#0F172A] [font-family:'Inter'] text-[24px] font-normal leading-[36px] tracking-[0px] text-left">로그인</p>;
}
