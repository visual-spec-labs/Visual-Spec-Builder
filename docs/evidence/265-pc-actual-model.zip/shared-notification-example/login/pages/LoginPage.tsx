import { Title } from "../components/Title";
import { LoginButton } from "../components/LoginButton";
import { ForgotButton } from "../components/ForgotButton";
import { SharedNotification } from "../components/SharedNotification";

type Actions = {
  onNavigate: (target: string) => void;
  onOpenModal: (target: string) => void;
  onClose: () => void;
};

export default function LoginPage({ onNavigate, onOpenModal, onClose }: Actions) {
  return (
    <div data-node-id="root" className="flex flex-col gap-[16px] pt-[24px] pr-[24px] pb-[24px] pl-[24px] justify-start items-stretch bg-[#F7F8FA] w-full flex-[1_0_auto]">
      <Title />
      <LoginButton onNavigate={onNavigate} />
      <ForgotButton onOpenModal={onOpenModal} />
      <SharedNotification onNavigate={onNavigate} onOpenModal={onOpenModal} onClose={onClose} />
    </div>
  );
}
